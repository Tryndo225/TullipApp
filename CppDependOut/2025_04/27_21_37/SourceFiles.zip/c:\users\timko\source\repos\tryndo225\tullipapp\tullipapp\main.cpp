#include "DateTime.h"
#include "Data_Helper_Types.h"

int main(int argc, char* argv[])
{
	try
	{
		DateTime time_now = DateTime(14, 6, 2003, 3, 45, 00);
		std::cout << "Current date and time: " << time_now << std::endl;
		std::cout << Date::get_weekday_from_date(time_now) << std::endl;
		std::cout << (Date::get_current_date() - time_now).get_year();
	}
	catch (const DateTimeError& e)
	{
		std::cout << e;
	}
	catch (...)
	{
		std::cout << "Unknown error occurred.";
	};

	return 0;
}