#ifndef DATABASE_PARSER_FUNCTIONS_H_
#define DATABASE_PARSER_FUNCTIONS_H_

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "DataBase.h"
#include "Lesson.h"
#include "Person.h"

/**
* @brief Parses a lesson from a CSV line.
* @details This function takes a CSV line representing a lesson and parses it into a Lesson object.
* @param line The CSV line to parse.
* @param database The database to use for looking up employees and children.
* @return A Lesson object created from the parsed data.
*/
void parse_lesson(std::string& line, Database& database);
void parse_child(const std::string& line, Database& database);
void parse_parent(const std::string& line, Database& database);
void parse_employee(const std::string& line, Database& database);

#endif // !DATABASE_PARSER_FUNCTIONS_H_
